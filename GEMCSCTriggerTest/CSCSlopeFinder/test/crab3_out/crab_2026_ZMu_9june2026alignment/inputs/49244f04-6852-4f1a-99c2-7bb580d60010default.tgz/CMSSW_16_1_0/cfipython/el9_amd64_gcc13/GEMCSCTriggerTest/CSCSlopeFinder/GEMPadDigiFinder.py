import FWCore.ParameterSet.Config as cms

def GEMPadDigiFinder(*args, **kwargs):
  mod = cms.EDAnalyzer('GEMPadDigiFinder',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
