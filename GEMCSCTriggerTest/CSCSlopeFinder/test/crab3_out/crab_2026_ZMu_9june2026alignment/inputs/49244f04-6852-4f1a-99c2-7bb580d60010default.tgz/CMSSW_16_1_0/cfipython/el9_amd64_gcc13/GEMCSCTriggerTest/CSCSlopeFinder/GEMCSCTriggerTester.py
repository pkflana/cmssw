import FWCore.ParameterSet.Config as cms

def GEMCSCTriggerTester(*args, **kwargs):
  mod = cms.EDAnalyzer('GEMCSCTriggerTester',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
