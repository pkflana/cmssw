import FWCore.ParameterSet.Config as cms

def ZMuonFinder(*args, **kwargs):
  mod = cms.EDAnalyzer('ZMuonFinder',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
