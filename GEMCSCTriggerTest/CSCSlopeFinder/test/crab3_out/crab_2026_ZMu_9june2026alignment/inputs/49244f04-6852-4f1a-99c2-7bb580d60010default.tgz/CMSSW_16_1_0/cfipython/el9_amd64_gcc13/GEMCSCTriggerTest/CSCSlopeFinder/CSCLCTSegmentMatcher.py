import FWCore.ParameterSet.Config as cms

def CSCLCTSegmentMatcher(*args, **kwargs):
  mod = cms.EDAnalyzer('CSCLCTSegmentMatcher',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
