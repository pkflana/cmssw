import FWCore.ParameterSet.Config as cms

def CSCSegmentFinder(*args, **kwargs):
  mod = cms.EDAnalyzer('CSCSegmentFinder',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
