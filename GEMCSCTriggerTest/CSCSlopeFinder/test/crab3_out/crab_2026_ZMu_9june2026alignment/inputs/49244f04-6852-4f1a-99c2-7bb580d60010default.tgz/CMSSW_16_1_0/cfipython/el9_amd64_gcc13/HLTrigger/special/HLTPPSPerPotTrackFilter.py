import FWCore.ParameterSet.Config as cms

def HLTPPSPerPotTrackFilter(*args, **kwargs):
  mod = cms.EDFilter('HLTPPSPerPotTrackFilter',
    pixelLocalTrackInputTag = cms.InputTag('ctppsPixelLocalTracks'),
    stripLocalTrackInputTag = cms.InputTag('totemRPLocalTrackFitter'),
    diamondLocalTrackInputTag = cms.InputTag('ctppsDiamondLocalTracks'),
    pixelFilter = cms.VPSet(
      cms.PSet(
        detid = cms.uint32(2022703104),
        maxTracks = cms.int32(-1),
        minTracks = cms.int32(2)
      ),
      cms.PSet(
        detid = cms.uint32(2023227392),
        maxTracks = cms.int32(-1),
        minTracks = cms.int32(2)
      ),
      cms.PSet(
        detid = cms.uint32(2039480320),
        maxTracks = cms.int32(-1),
        minTracks = cms.int32(2)
      ),
      cms.PSet(
        detid = cms.uint32(2040004608),
        maxTracks = cms.int32(-1),
        minTracks = cms.int32(2)
      ),
      template = cms.PSetTemplate(
        detid = cms.uint32(0),
        minTracks = cms.int32(-1),
        maxTracks = cms.int32(-1)
      )
    ),
    stripFilter = cms.VPSet(
      template = cms.PSetTemplate(
        detid = cms.uint32(0),
        minTracks = cms.int32(-1),
        maxTracks = cms.int32(-1)
      )
    ),
    diamondFilter = cms.VPSet(
      template = cms.PSetTemplate(
        detid = cms.uint32(0),
        minTracks = cms.int32(-1),
        maxTracks = cms.int32(-1)
      )
    ),
    triggerType = cms.int32(91),
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
