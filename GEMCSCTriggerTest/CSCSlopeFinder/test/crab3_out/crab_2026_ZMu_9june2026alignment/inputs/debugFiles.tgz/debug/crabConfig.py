from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'crab3_out'
config.General.transferOutputs = True
config.General.requestName = '2026_ZMu_9june2026alignment'
config.section_('JobType')
config.JobType.psetName = 'run_unpack_CSCGEM_matcher.py'
config.JobType.numCores = 1
config.JobType.allowUndistributedCMSSW = True
config.JobType.maxJobRuntimeMin = 420
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = '2026_ZMu_9june2026alignment'
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/Muon0/Run2026D-ZMu-PromptReco-v1/RAW-RECO'
config.Data.outLFNDirBase = '/store/user/pflanaga/GEMCSCTrigger/2026_ZMu/'
config.Data.publication = False
config.Data.unitsPerJob = 1
config.section_('Site')
config.Site.ignoreGlobalBlacklist = True
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
