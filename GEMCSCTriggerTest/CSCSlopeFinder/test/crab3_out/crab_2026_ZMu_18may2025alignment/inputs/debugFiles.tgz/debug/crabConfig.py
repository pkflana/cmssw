from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.requestName = '2026_ZMu_18may2025alignment'
config.General.workArea = 'crab3_out'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'run_unpack_CSCGEM_matcher.py'
config.JobType.allowUndistributedCMSSW = True
config.JobType.pluginName = 'Analysis'
config.JobType.numCores = 1
config.JobType.maxJobRuntimeMin = 420
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = '2026_ZMu_18may2025alignment'
config.Data.publication = False
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/Muon0/Run2026D-ZMu-PromptReco-v1/RAW-RECO'
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/pflanaga/GEMCSCTrigger/2026_ZMu/'
config.section_('Site')
config.Site.ignoreGlobalBlacklist = True
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
